document.addEventListener('DOMContentLoaded', function () {
    // Load photos
    const photoContainer = document.getElementById('photos');
    const photos = ['images/web.jpg','images/background.jpg', 'images/app.png', 'images/design.png']; // Ensure paths are correct
    photos.forEach(photo => {
        const img = document.createElement('img');
        img.src = photo;
        photoContainer.appendChild(img);
    });

    // Contact form submission
    const form = document.getElementById('contact-form');
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        const formData = new FormData(form);
        // Send form data to server using fetch or any other method
        console.log('Form submitted:', formData);
        form.reset();
    });
});
